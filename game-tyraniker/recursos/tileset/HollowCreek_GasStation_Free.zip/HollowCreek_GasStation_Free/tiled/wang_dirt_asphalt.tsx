<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="wang_dirt_asphalt" tilewidth="16" tileheight="16" tilecount="16" columns="4">
 <image source="../tiles/wang_dirt_asphalt.png" width="64" height="64"/>
 <wangsets>
  <wangset name="dirt-asphalt" type="corner" tile="-1">
   <wangcolor name="dirt" color="#3e5a2e" tile="0" probability="1"/>
   <wangcolor name="asphalt" color="#6b4a33" tile="15" probability="1"/>
   <wangtile tileid="0" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="1" wangid="0,1,0,1,0,1,0,2"/>
   <wangtile tileid="2" wangid="0,2,0,1,0,1,0,1"/>
   <wangtile tileid="3" wangid="0,2,0,1,0,1,0,2"/>
   <wangtile tileid="4" wangid="0,1,0,1,0,2,0,1"/>
   <wangtile tileid="5" wangid="0,1,0,1,0,2,0,2"/>
   <wangtile tileid="6" wangid="0,2,0,1,0,2,0,1"/>
   <wangtile tileid="7" wangid="0,2,0,1,0,2,0,2"/>
   <wangtile tileid="8" wangid="0,1,0,2,0,1,0,1"/>
   <wangtile tileid="9" wangid="0,1,0,2,0,1,0,2"/>
   <wangtile tileid="10" wangid="0,2,0,2,0,1,0,1"/>
   <wangtile tileid="11" wangid="0,2,0,2,0,1,0,2"/>
   <wangtile tileid="12" wangid="0,1,0,2,0,2,0,1"/>
   <wangtile tileid="13" wangid="0,1,0,2,0,2,0,2"/>
   <wangtile tileid="14" wangid="0,2,0,2,0,2,0,1"/>
   <wangtile tileid="15" wangid="0,2,0,2,0,2,0,2"/>
  </wangset>
 </wangsets>
</tileset>
